# Light Planner

Takes a marked-up floor plan image and produces an ambient lighting layout —
grid, large lights, small lights — that you can export to DXF, CSV, JSON, SVG or PNG.

## Running it

```bash
npm install
npm run dev          # http://localhost:5178
```

`npm run test` runs the algorithm test suite in Node (no browser needed).

## Marking up a plan

Two annotations on top of any plan image (screenshot, scan, PDF export):

| Mark | Meaning |
|---|---|
| **Solid green** closed box or polyline | the area to light |
| **Red dotted circle** | the ceiling fan |

The green outline must be a closed loop. Small breaks are sealed automatically
(the app escalates the seal radius until the enclosed area matches the marked
box); if it can't close the loop it says so rather than guessing.

The red mark has to be genuinely circular — red text and dimension strings are
rejected by a roundness test, so they won't be mistaken for a fan.

## Scale

Three routes, in the order you'll actually want them:

1. **From fan** (default). You already drew the fan, and a fan is a standard
   object — 1200mm sweep unless you pick otherwise. Zero extra input.
2. **Measure.** Click the two ends of something identifiable (door leaf, sofa,
   WC, bed, car bay) and pick what it is from the list.
3. **Manual.** Type pixels-per-foot directly.

There's also an optional "Let Claude find the scale" panel — it sends the image
to the Claude API and asks it to spot a door, fixture or dimension line. Needs
your own API key, which stays in this browser's local storage.

## How the layout is computed

```
rectify → anchors → 1-D partition per axis → cells → matching → align → fixtures
```

1. **Rectify.** The traced green outline is simplified, forced to 90°, and its
   coordinates are clustered so near-aligned walls become aligned.
2. **Anchors.** Every wall line is a hard grid anchor. The fan is a soft anchor.
3. **Partition.** Anchors slice each axis into bands. Each band of width `W` is
   split into `round(W/6)` pieces, choosing between `n-1`, `n` and `n+1` by a
   score that rewards a cut line or cell centre landing on the fan. This is
   where "squarish, but sizes vary to suit the walls" comes from.
4. **Cells.** Cross the two partitions; keep cells at least half inside the room.
5. **Matching.** A large light consumes two adjacent cells; a small light
   consumes one. So the layout is a **maximum-weight maximum-cardinality
   matching** on the cell-adjacency graph, restricted to pairs whose shared edge
   satisfies the wall-distance rule. Cell graphs are bipartite (checkerboard
   parity), so no Blossom algorithm is needed. Matched pairs get a large light
   on the shared grid line; unmatched cells get a small light at their centre.
   Preferences — depth into the room, the long axis, alignment with the fan,
   cell squareness — are edge weights, not special cases.
6. **Align.** Light coordinates are clustered into rows and columns and snapped,
   preferring the fan's coordinate. A large light on a vertical grid line has
   its x fixed by the grid, so only its y can slide, and only along the shared
   edge.
7. **Fixtures.** A large light stays on its grid intersection, so if the fan
   fouls that point the pair is simply unavailable and both cells fall through
   to small lights. A small light, by contrast, is **moved within its cell** to
   the nearest point that clears the fan — never deleted, because a deleted
   light leaves the cell dark. If a cell has nowhere to go at all, the light
   stays and the app flags a clash rather than silently dropping it.

**Invariant: every cell gets exactly one light.** The sidebar shows `Cells lit`
so a hole can't hide, and `tools/test-planner.mjs` asserts it on every case.

`src/lib/` is plain JS with no DOM dependency except `detect.js`, so the engine
is testable in Node and reusable elsewhere.

## The wall-distance rule

A large light must have **at least 5 ft to the nearest wall, in every
direction** — true nearest-wall distance, so corners and inward (reflex)
corners count too. Any candidate position closer than that becomes a small
light at its cell centre instead.

The design intent is 6 ft. 5 ft is that rule carrying its working tolerance,
and it turns out to be the robust choice rather than a fudge. With ~6 ft cells,
candidate positions only ever sit at ~3 ft from a wall (cell centres, outer
band) or at 6 ft and beyond (interior grid lines) — nothing lands in between.
So the threshold sits in an empty gap:

```
threshold      3.5   4.0   4.5   5.0   5.5   6.0   6.5     (large lights)
36 x 24 ft      8     8     8     8     8     8     4
35.6 x 22.4     8     8     8     8     8     4     4
L 30 x 30       5     5     5     5     5     5     0
```

Everything from 3.5 to 5.5 gives the identical layout. At exactly 6.0 it turns
brittle: a room measuring 35.6 ft instead of 36 puts its grid line at 5.93 ft,
misses by ¾ of an inch, and flips half the large lights to small. 5 ft sits in
the middle of the stable plateau, which is why the layout doesn't wobble when
your drawn box is a few inches off.

The consequence, by design: **small lights ring the perimeter, large lights
fill the core.** A 12×12 ft room gets no large lights at all, and 18×18 is
about the smallest that admits one.

The slider ranges 2–9 ft if you want to see the rule bite differently.

## Known limits (v1)

- One region per image — the largest enclosed green area wins.
- Walls are assumed rectilinear. Diagonals become staircases.
- Beams, diffusers and sprinklers aren't read from the plan yet; only the fan is.
- A fan sitting near a cell centre pushes that light off-centre. Lower **Fan
  clearance** if you'd rather it stayed put.
- Scale from the fan carries the stroke width of your drawn circle (~2–4% high).
  Use Measure if you need it tighter.

## Test scripts

`tools/` needs `npm i -D playwright` to run the image-generating and
end-to-end scripts:

```bash
node tools/test-planner.mjs           # layout invariants on synthetic rooms
node tools/test-match-bruteforce.mjs  # matching vs brute force, 400 cases
node tools/make-plans.mjs             # regenerate public/samples/
node tools/e2e.mjs hall lshape        # drive the built app headless
```

`public/samples/` has five test plans, including one with a deliberately broken
green stroke and one with no fan, to check the failure paths.
