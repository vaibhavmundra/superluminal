import React, { forwardRef } from 'react';

const C = {
  region: '#16A34A', grid: '#6366F1', cell: '#6366F1',
  large: '#0A0A0A', small: '#6366F1', fan: '#DC2626', measure: '#B45309',
};

const PlanCanvas = forwardRef(function PlanCanvas(
  { src, width, height, plan, fanPx, pxPerFt, layers, zoom, measure, onCanvasClick, toPx },
  ref
) {
  const s = pxPerFt || 1;
  const lw = Math.max(width, height) / 900; // line weight that survives any image size

  const gridPath = () => {
    if (!plan?.ok) return null;
    const b = plan.boundsPx;
    return (
      <g stroke={C.grid} strokeWidth={lw} opacity="0.42" strokeDasharray={`${lw * 6} ${lw * 4}`}>
        {plan.xLinesPx.map((x, i) => <line key={'x' + i} x1={x} y1={b.y0} x2={x} y2={b.y1} />)}
        {plan.yLinesPx.map((y, i) => <line key={'y' + i} x1={b.x0} y1={y} x2={b.x1} y2={y} />)}
      </g>
    );
  };

  return (
    <svg
      ref={ref}
      className="plan"
      viewBox={`0 0 ${width} ${height}`}
      style={{ width: width * zoom, maxWidth: 'none' }}
      onClick={onCanvasClick}
    >
      <defs>
        {plan?.ok && (
          <clipPath id="roomclip">
            <polygon points={plan.polygonPx.map((p) => `${p.x},${p.y}`).join(' ')} />
          </clipPath>
        )}
      </defs>

      {layers.plan && <image href={src} x="0" y="0" width={width} height={height} opacity={layers.dim ? 0.42 : 1} />}

      {plan?.ok && (
        <>
          {layers.cells && (
            <g clipPath="url(#roomclip)">
              {plan.cellsPx.map((c, i) => (
                <rect key={i} x={c.x0} y={c.y0} width={c.x1 - c.x0} height={c.y1 - c.y0}
                  fill={C.cell} opacity={(c.i + c.j) % 2 ? 0.05 : 0.015} />
              ))}
            </g>
          )}
          {layers.grid && <g clipPath="url(#roomclip)">{gridPath()}</g>}
          {layers.region && (
            <polygon points={plan.polygonPx.map((p) => `${p.x},${p.y}`).join(' ')}
              fill="none" stroke={C.region} strokeWidth={lw * 2.4} strokeLinejoin="round" />
          )}
        </>
      )}

      {layers.fan && fanPx && (
        <g>
          <circle cx={fanPx.x} cy={fanPx.y} r={fanPx.r} fill="none" stroke={C.fan}
            strokeWidth={lw * 1.6} strokeDasharray={`${lw * 5} ${lw * 5}`} opacity="0.85" />
          <circle cx={fanPx.x} cy={fanPx.y} r={lw * 3} fill={C.fan} />
        </g>
      )}

      {layers.lights && plan?.ok && plan.lightsPx.map((l) => {
        const R = (l.kind === 'large' ? 0.52 : 0.3) * s;
        const col = l.kind === 'large' ? C.large : C.small;
        return (
          <g key={l.id}>
            {l.kind === 'large' && (
              <circle cx={l.x} cy={l.y} r={R * 1.9} fill={col} opacity="0.07" />
            )}
            <circle cx={l.x} cy={l.y} r={R} fill={l.kind === 'large' ? col : '#fff'}
              stroke={col} strokeWidth={lw * 1.7} />
            {l.kind === 'small' && <circle cx={l.x} cy={l.y} r={R * 0.42} fill={col} />}
            {l.kind === 'large' && (
              <line
                x1={l.axis === 'v' ? l.x : l.x - R * 1.7} y1={l.axis === 'v' ? l.y - R * 1.7 : l.y}
                x2={l.axis === 'v' ? l.x : l.x + R * 1.7} y2={l.axis === 'v' ? l.y + R * 1.7 : l.y}
                stroke={col} strokeWidth={lw * 1.1} opacity="0.5" />
            )}
            {layers.labels && (
              <text x={l.x + R * 1.6} y={l.y - R * 1.2} fontSize={s * 0.5}
                fontFamily="JetBrains Mono, monospace" fill={col} opacity="0.75">{l.id}</text>
            )}
          </g>
        );
      })}

      {measure?.a && (
        <g stroke={C.measure} strokeWidth={lw * 2} fill={C.measure}>
          <circle cx={measure.a.x} cy={measure.a.y} r={lw * 4} />
          {measure.b && <>
            <line x1={measure.a.x} y1={measure.a.y} x2={measure.b.x} y2={measure.b.y} />
            <circle cx={measure.b.x} cy={measure.b.y} r={lw * 4} />
          </>}
        </g>
      )}
    </svg>
  );
});

export default PlanCanvas;
