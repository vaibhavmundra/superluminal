import { planLights, DEFAULTS } from '../src/lib/planner.js';
import { rectifyPolygon } from '../src/lib/geometry.js';

const R = (w,h)=>[{x:0,y:0},{x:w,y:0},{x:w,y:h},{x:0,y:h}];
function show(name, poly, fixtures=[], opts={}) {
  const r = planLights(poly, fixtures, opts);
  if(!r.ok){ console.log(`${name}: FAILED - ${r.reason}`); return r; }
  const cellSizes = r.cells.map(c=>`${c.w.toFixed(1)}x${c.h.toFixed(1)}`);
  console.log(`${name}`);
  console.log(`  grid ${r.xLines.length-1} x ${r.yLines.length-1} cols/rows -> ${r.stats.cells} cells, avg side ${r.stats.avgCell.toFixed(2)}ft`);
  console.log(`  lights: ${r.stats.large} large, ${r.stats.small} small  (area ${r.stats.areaSqft.toFixed(0)} sqft)`);
  const uniq=[...new Set(cellSizes)]; console.log(`  cell sizes: ${uniq.slice(0,6).join(', ')}${uniq.length>6?' …':''}`);
  // invariants
  const cellsCovered=new Set(); r.lights.forEach(l=>l.cells.forEach(c=>cellsCovered.add(c)));
  console.log(`  coverage: ${cellsCovered.size}/${r.stats.cells} cells served`);
  const dup = r.lights.some((a,i)=>r.lights.some((b,j)=>j>i && Math.hypot(a.x-b.x,a.y-b.y)<0.4));
  console.log(`  overlapping lights: ${dup?'YES (bad)':'none'}`);
  return r;
}

console.log('=== default: nearest wall >= 5 ft ===\n');
show('12x12 square', R(12,12));
show('18x18 square', R(18,18));
show('24x36 hall', R(36,24));
show('4ft x 30ft corridor', R(30,4));
show('L-shape 30x30 with 18x18 bite', [{x:0,y:0},{x:30,y:0},{x:30,y:12},{x:12,y:12},{x:12,y:30},{x:0,y:30}]);
show('odd 13x21 (rounding)', R(13,21));

console.log('\n=== the rule at other thresholds ===\n');
show('36x24 @ 6ft all round', R(36,24), [], {minWallDistance:6});
show('36x24 @ 4ft all round', R(36,24), [], {minWallDistance:4});
show('18x18 @ 5ft', R(18,18), [], {minWallDistance:5});

console.log('\n=== with a ceiling fan ===\n');
const f=[{type:'fan',x:18,y:12,r:2.5}];
const withFan = show('36x24 hall + fan at (18,12)', R(36,24), f);
const near = withFan.lights.filter(l=>Math.hypot(l.x-18,l.y-12)<5);
console.log('  lights within 5ft of fan:', near.map(l=>`${l.kind}@(${l.x.toFixed(1)},${l.y.toFixed(1)})`).join(' ')||'none');
console.log('  lights sharing fan x=18:', withFan.lights.filter(l=>Math.abs(l.x-18)<0.3).length);
console.log('  lights sharing fan y=12:', withFan.lights.filter(l=>Math.abs(l.y-12)<0.3).length);

console.log('\n=== alignment quality on 36x24 ===');
const r = withFan;
const cols=[...new Set(r.lights.map(l=>Math.round(l.x*4)/4))].sort((a,b)=>a-b);
const rows=[...new Set(r.lights.map(l=>Math.round(l.y*4)/4))].sort((a,b)=>a-b);
console.log('  distinct x positions:', cols.length, cols.map(v=>v.toFixed(1)).join(' '));
console.log('  distinct y positions:', rows.length, rows.map(v=>v.toFixed(1)).join(' '));

console.log('\n=== regression: a fan must never leave a cell dark ===\n');
{
  const room=[{x:0,y:0},{x:23.9,y:0},{x:23.9,y:12.9},{x:0,y:12.9}];
  const F={x:6.48,y:6.80,r:2.02};
  const r=planLights(room,[{type:'fan',...F}]);
  const need=F.r+2.0;
  const inZone=r.lights.filter(l=>Math.hypot(l.x-F.x,l.y-F.y)<need-1e-6);
  console.log(`23.9x12.9 + fan near a cell centre: ${r.stats.served}/${r.stats.cells} cells served (must be all)`);
  console.log(`  ${r.stats.large}L/${r.stats.small}S, ${r.stats.nudged} nudged, ${r.stats.clashes} unavoidable clashes`);
  console.log(`  lights inside the fan zone: ${inZone.length} (must be 0)`);
  console.log(`  VERDICT: ${r.stats.served===r.stats.cells && inZone.length===0 ? 'PASS' : 'FAIL'}`);
}
